.. module:: optuna

Tutorial
========

.. toctree::
    :maxdepth: 2

   first
   configurations
   rdb
   distributed
   cli
   attributes
   pruning
