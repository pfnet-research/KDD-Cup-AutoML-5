.. module:: optuna

API Reference
=============

.. toctree::
    :maxdepth: 2

    integration
    logging
    pruners
    samplers
    structs
    study
    trial
    visualization
